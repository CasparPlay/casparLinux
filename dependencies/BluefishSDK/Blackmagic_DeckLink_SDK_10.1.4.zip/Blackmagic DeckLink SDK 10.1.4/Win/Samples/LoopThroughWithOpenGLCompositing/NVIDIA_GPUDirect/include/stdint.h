/* minimal types from stdint.h needed by DVPAPI.h */
typedef unsigned int uint32_t;
typedef _ULonglong uint64_t;
