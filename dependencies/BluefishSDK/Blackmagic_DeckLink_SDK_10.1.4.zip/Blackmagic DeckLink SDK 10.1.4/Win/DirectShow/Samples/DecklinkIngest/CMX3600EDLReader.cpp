//-----------------------------------------------------------------------------
// CMX3600EDLReader.cpp
//
// Desc: A class for reading CMX3600 EDLs.
//
// Copyright (c) Blackmagic Design 2007. All rights reserved.
//-----------------------------------------------------------------------------

#include "stdafx.h"
#include "CMX3600EDLReader.h"

//-----------------------------------------------------------------------------
// Parse
//
HRESULT CCMX3600EDLReader::Parse(void)
{
	HRESULT hr = S_OK;
	
	return hr;
}
