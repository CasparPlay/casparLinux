//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GMFPreview.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_DEVICE                      201
#define IDC_PREVIEW                     1000
#define IDC_DEVICE                      1001
#define IDC_FOLDER                      1002
#define IDC_CAPTURE                     1003
#define IDC_STOPCAPTURE                 1004
#define IDC_LIST1                       1005
#define IDC_DEVICELIST                  1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
